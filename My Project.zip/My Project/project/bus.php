<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>


.footer {
  background-color: #0052cc;
  padding: 20px;
}
table {
  border-collapse: collapse;
  width: 100%;
  font-size: 16px;
}

 td {
  text-align: center;
  padding: 8px;

}
h2 {
	 text-align: center;
  	 color: #004080;
  	 padding: 40px;

}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
</head>
<body>

	<div class="jumbotron text-center">
		<img src="ss.png" width="100" height="70"><br><br>
  <h1>@ShebaService.com</h1><br>
  <p> Anyone can booking ticket from this page easily with security.</p>
	</div>

 	<h2><b> Available Bus Roads </b></h2>
 	<table>
 	<tr>
  	<td>Dhaka to Dinajpur</td>
 	<td> Dhaka to Panchagor</td>
  	<td> Dhaka to Nilphamari</td>
  	<td>Dhaka to Kurigram</td>
  	<td> Dhaka to Rangpur</td>
 	 </tr>

 	 <tr>
  	<td>Dhaka to Thakurgaon</td>
 	<td> Dhaka to Cox's Bazar</td>
  	<td> Dhaka to Feni</td>
  	<td> Dhaka to Darshana</td>
  	<td> Dhaka to Joypurhat</td>
 	 </tr>

 	 <tr>
  	<td> Dhaka to Satkhira</td>
 	<td>Dhaka to Bogra</td>
  	<td>Dhaka to Naogaon</td>
  	<td> Dhaka to Chapai Nawabganj</td>
  	<td> Dhaka to Gopalganj</td>
 	 </tr>

 	 <tr>
  	<td>Dhaka to Hili</td>
 	<td>Dhaka to Chittagong</td>
  	<td> Dhaka to Khulna</td>
  	<td> Dhaka to Sylhet</td>
  	<td> Dhaka to Barisal</td>
 	 </tr>

 	 <tr>
  	<td> Dhaka to Bandarban</td>
 	<td>Dhaka to Teknaf</td>
  	<td>Dhaka to Khagrachari</td>
  	<td> Dhaka to Moulvibazar</td>
  	<td>Dhaka to Sreemangal</td>
 	 </tr>

 	 <tr>
  	<td>Dhaka to Rangamati</td>
 	<td> Dhaka to Kolkata</td>
  	<td> Dhaka to Rajshahi</td>
  	<td>Dhaka to Nazirhat</td>
  	<td> Dhaka to Jessore</td>
 	 </tr>

 	 <tr>
  	<td> Dhaka to Kushtia</td>
 	<td>Dhaka to Gaibandha</td>
  	<td>Dhaka to Jhenaidah</td>
  	<td>Dhaka to Brahmanbaria</td>
 	 </tr>

</table>


 	<h2><b>Available Bus Operators</b></h2>

 	<table>
 	<tr>
  	<td>Abdullah Paribahan</td>
 	<td>Agomony Express</td>
  	<td>Akota Transport</td>
  	<td>Al-Mobaraka Paribahan</td>
  	<td>Alhamra Paribahan</td>
 	 </tr>

 	<tr>
  	<td>Barkat Travels</td>
 	<td>Chaklader Paribahan</td>
  	<td>Comfort Line Pvt Ltd</td>
  	<td>Dhaka Line</td>
  	<td>Diganta Express</td>
 	 </tr>

 	<tr>
  	<td>Diganta Paribahan</td>
 	<td>Dipjol Enterprise</td>
  	<td>Elish Paribahan</td>
  	<td>Emad Enterprise</td>
  	<td>Ena Transport (Pvt) Ltd</td>
 	 </tr>

 	<tr>
  	<td>Green Line Paribahan</td>
 	<td>Hanif Enterprise</td>
  	<td>HIMACHOL</td>
  	<td>Islam Paribahan</td>
  	<td>Kanak Paribahan Ltd</td>
 	 </tr>

 	<tr>
  	<td>M M Paribahan</td>
 	<td>Manik Express</td>
  	<td>Nabil Paribahan</td>
  	<td>New S.B Super Deluxe</td>
  	<td>Ranga Provat Paribahan Ltd</td>
 	 </tr>

 	<tr>
  	<td>Relax Transport Ltd.</td>
 	<td>Royal Coach</td>
  	<td>Rozina Enterprise</td>
  	<td>S.B Super Deluxe</td>
  	<td>S.R Travels (Pvt) Ltd</td>
 	 </tr>

 	<tr>
  	<td>Sagorika Enterprise</td>
 	<td>Saintmartin Hyundai</td>
  	<td>Saintmartin Paribahan Ltd</td>
  	<td>Saintmartin Travels</td>
  	<td>Shahzadpur Travels</td>
 	 </tr>

 	<tr>
  	<td>Sheba Green Line</td>
 	<td>Sheba Transport</td>
  	<td>Shohagh Paribahan</td>
  	<td>Shoukhin Paribahan</td>
  	<td>Shuvo Bosundhara Paribahan</td>
 	 </tr>

 	<tr>
  	<td>Shyamoli Paribahan</td>
 	<td>Soudia Air Conr</td>
  	<td>Soudia Coach Service</td>
  	<td>SP Golden Line</td>
  	<td>Star Line Special Ltd.</td>
 	 </tr>

 	<tr>
  	<td>Tisha Group</td>
 	<td>Tuba Line</td>
  	<td>Tungipara Express</td>
  	<td>Year-71</td>
 	 </tr>

 	</table><br><br>

<?php

?>
<div class="footer">
</div>
 
</body>
</html>
