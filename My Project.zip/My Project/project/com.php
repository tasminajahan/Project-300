<?php
 $cname=$_POST['cname'];
 $email=$_POST['email'];
 $comments=$_POST['comments'];

if(!empty($cname) || !empty($email) || !empty($comments)){
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword ="";
	$dbname = "passenger";

	$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);

	if($conn->connect_errno){
	die('Connection Failed :'.$conn->connect_error);
	}else{
		$INSERT = "INSERT Into comments(Name,Email,Comment)  values(?, ?, ?)";
		if($INSERT){
			$stmt = $conn->prepare($INSERT);
			$stmt->bind_param("sss", $cname,$email,$comments);
			$stmt->execute();
			echo "Send Successfully...";
		}else{
			echo "Something Wrong!!";
		}
		$stmt->close();
	    $conn->close();
	}

}else{
	echo "All field are required";
	die();
}

?>