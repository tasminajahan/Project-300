<?php
 $name=$_POST['name'];
 $Pnumber=$_POST['Pnumber'];
 $form=$_POST['form'];
 $to=$_POST['to'];
 $number=$_POST['number'];
 $BusTrain=$_POST['BusTrain'];
 $date=$_POST['date'];

if(!empty($name) || !empty($Pnumber) || !empty($form) || !empty($to) || !empty($number) || !empty($BusTrain) || !empty($date)){
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword ="";
	$dbname = "passenger";

	$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);

	if($conn->connect_errno){
	die('Connection Failed :'.$conn->connect_error);
	}else{
		$INSERT = "INSERT Into passenger_list(Name,PhoneNumber,Form,To,NumberOfSeat,BusTrain,Date)  values(?, ?, ?, ?, ?, ?, ?)";
		if($INSERT){
			$stmt = $conn->prepare($INSERT);
			$stmt->bind_param("sississ", $name,$Pnumber,$form,$to,$number,$BusTrain,$date);
			$stmt->execute();
			echo "Submit Successfully...";
		}else{
			echo "Something Wrong!!";
		}
		$stmt->close();
	    $conn->close();
	}

}else{
	echo "All field are required";
	die();
}
}

?>