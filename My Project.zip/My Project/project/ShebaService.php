<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sheba service</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>


.footer {
  background-color: #0052cc;
  padding: 20px;
}
.button1 {
  background-color: #4db8ff;  
}
*{
  margin: 0;
  padding: 0;
}
.register{

  background: #e6e6e6;
  width: 470px;
  color: black;
  font-size: 15px;
  padding: 40px;
  border-radius: 7px;
}
#register{
  margin-left:100px;
}
#name{
  width: 250px;
  border-width: 0.3px;
  border-color: #0052cc;
  
}
#Pnumber{
  width: 250px;
  border-width: 0.3px;
  border-color: #0052cc;
}
#usr{
  width: 250px;
  border-width: 0.3px;
  border-color: #0052cc;
}
#number{
  width: 250px;
  border-width: 0.3px;
  border-color: #0052cc;
}

h3{
  text-align: center;
}


</style>

</head>
<body>
<div class="jumbotron text-center">
  <img src="ss.png" width="100" height="70"><br><br>
  <h1>@ShebaService.com</h1><br>
  <p> Anyone can booking ticket from this page easily with security.</p>
</div>
  <div class="container">
  <div class="btn-group btn-group-justified">
    <a href="#" class="btn btn-primary" onclick="window.open('http://localhost/project/bus.php')">Bus</a>
    <a href="#" class="btn btn-primary" onclick="window.open('http://localhost/project/train.php')">Train</a>
     <div class="btn-group">
      <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
      Pay <span class="caret"></span></button>
      <ul class="dropdown-menu" role="menu">
        <li><a href="#">Bkash</a></li>
        <li><a href="#">Rocket</a></li>
        <li><a href="#">AB Bank</a></li>
        <li><a href="#">Bangladesh Bank</a></li>
      </ul>
    </div>
  </div><br><br>

    <div class= "register">
    <h3><b> Ticket Collcet </b> <br><br></h3>
   <form action="connect.php" method="post">
    <div class="form-group">
      <label1 for="usr">Name: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="text" id="name" name="name" required>
    </div>
    <div class="form-group">
      <label1 for="usr">Phone number:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="Pnumber" id="Pnumber" name="Pnumber" required>
    </div>
     <div class="form-group">
      <label1 for="usr">Form:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="text"  id="usr" name="form" required>
    </div>
    <div class="form-group">
      <label1 for="usr">To:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="text"  id="usr" name="to" required>
    </div>
    <div class="form-group">
      <label1 for="usr">Number of seat:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="number"  id="number" name="number" required>
    </div>
    <div class="form-group">
      <label1 for="usr">Bus or Train name:&nbsp&nbsp</label1>
      <input type="text"  id="usr" name="BusTrain" required>
    </div>
    <div class="form-group">
      <label1 for="usr">Date:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label1>
      <input type="Date" id="usr" name="date" required>
    </div><br>
    <button type="submit" class="btn btn-primary">Submit</button>
 </form>
</div><br><br><br>


<div class="container">
  <h2>Owner of Company</h2>
  <div class="media">
    <div class="media-left">
      <img src="profile.png" class="media-object" style="width:60px">
    </div>
    <div class="media-body">
      <h4 class="media-heading">Tasmina Jahan Nishi <small><i>Posted on December 10, 2020</i></small></h4>
      <p>CEO of @ShebaService.com</p><br>

      <div class="media">
        <div class="media-left">
          <img src="img_avatar.png" class="media-object" style="width:60px">
        </div>
        <div class="media-body">
          <h4 class="media-heading">John Doe <small><i>Posted on December 10, 2020</i></small></h4>
          <p>Manager of @ShebaService.com</p>
        </div>
      </div>
    </div>
  </div><br><br>
  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="train.jpg" width="400" height="300">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<img src="bus.jpg" width="400" height="300"><br><br>
  </div><br>

  

<div class="container-fluid text-center">
  <h1>SERVICES</h1><br>
  <h4>What we offer</h4>
  <br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-bus"></span>
      <h4><b>BUS</b></h4>
      <p>Available Bus Operators, Available Bus Routes etc</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-heart"></span>
      <h4><b>LOVE</b></h4>
      <p>Always Take Care...</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-train"></span>
      <h4><b>Train</b></h4>
      <p>Available Train Operators, Available Train Routes etc</p>
    </div>
    </div>
    <br><br>
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-safe"></span>
      <h4><b>Safe Journey</b></h4>
      <p>Available Medical Service....</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-food"></span>
      <h4><b>Food</b></h4>
      <p>Available Food....</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-security"></span>
      <h4><b>Security</b></h4>
      <p>Security level high....</p>
    </div>
  </div>
</div><br><br>

<div class="container-fluid bg-grey">
  <h2 class="text-center">CONTACT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Sylhet, Bangladesh</p>
      <p><span class="glyphicon glyphicon-phone"></span> +00 1910099192</p>
      <p><span class="glyphicon glyphicon-envelope"></span> taminanishi@gmail.com</p>
    </div>

    <div>
    <form action="com.php" method="post">
    <div class="col-sm-7">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="cname" name="cname" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="button1 btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
  </form>
</div>
  </div>
</div>

<div class="footer">
</div>


</body>
</html>
