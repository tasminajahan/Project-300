<!DOCTYPE html>
<html>
<body>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
 
.footer {
  background-color: #0052cc;
  padding: 20px;
}
table {
  border-collapse: collapse;
  width: 100%;
  font-size: 16px;
}

 td {
  text-align: center;
  padding: 8px;
  
}
h2 {
	 text-align: center;
  	 color: #004080;
  	 padding: 40px;

}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
</head>
<body>

	<div class="jumbotron text-center">
		<img src="ss.png" width="100" height="70"><br><br>
  <h1>@ShebaService.com</h1><br>
  <p> Anyone can booking ticket from this page easily with security.</p>
	</div>
 
 	<h2><b>Available Train Operators</b></h2>
 	<table>
 	<tr>
  	<td>702 Subarna Express</td>
 	<td>704 Mahanagar Provati</td>
  	<td>705	Ekota Express</td>
  	<td>707	Tista Express</td>
  	<td>709	Parabat Express</td>
 	 </tr>

 	 <tr>
  	<td>712	Upokol Express</td>
 	<td>717	Joyantika Express</td>
  	<td>722	Mohanagar Express</td>
  	<td>726	Sundarban Express</td>
  	<td>735	Agnibina Express</td>
 	 </tr>

 	 <tr>
  	<td>737	Egarosindhur Provati</td>
 	<td>739	Upaban Express</td>
  	<td>742	Turna Express</td>
  	<td>743	Brahmaputra Express</td>
  	<td>745	Jamuna Express</td>
 	 </tr>

 	 <tr>
  	<td>749	Egarosindhur Goduli</td>
 	<td>751	Lalmoni Express</td>
  	<td>753	Silk City Express</td>
  	<td>757	Drutojan Express</td>
  	<td>759	Padma Express</td>
 	 </tr>

 	 <tr>
  	<td>764	Chitra Express</td>
 	<td>765	Nilsagar</td>
  	<td>769	Dhumketue Express</td>
  	<td>771	Rangpur Express</td>
  	<td>773	Kalani Express</td>
 	 </tr>

 	 <tr>
  	<td>776	Sirajgonj Express</td>
 	<td>777	Haor Express</td>
  	<td>781	Kishorgonj Express</td>
  	<td>788	Sonar Bangla Express</td>
  	<td>789	Mohangonj Express</td>
 	 </tr>

 	 <tr>
  	<td>791	Banalata Express</td>
 	<td>793	Panchagarh Express</td>
  	<td>796	Benapole Express</td>
  	<td>797	Kurigram Express</td>
  	<td>35	Moitree Express*</td>
 	 </tr>

</table>


 	<h2><b>Available Train Roads</b></h2>

 	<table>
 	<tr>
  	<td>Dhaka District</td>
 	<td>Faridpur District</td>
  	<td>Gazipur District</td>
  	<td>Narayanganj District</td>
  	<td>Narsingdi District</td>
 	 </tr>

 	<tr>
  	<td>Tangail District</td>
 	<td>Chandpur District</td>
  	<td>Brahmanbaria District</td>
  	<td>Chittagong District</td>
  	<td>Comilla District</td>
 	 </tr>

 	<tr>
  	<td>Feni District</td>
 	<td>Noakhali District</td>
  	<td>Habiganj District</td>
  	<td>Moulvibazar District</td>
  	<td>Sunamganj District</td>
 	 </tr>

 	<tr>
  	<td>Sylhet District</td>
 	<td>Jamalpur District</td>
  	<td>Mymensingh District</td>
  	<td>Netrokona District</td>
  	<td>Bogra District</td>
 	 </tr>

 	<tr>
  	<td>Chapai Nawabganj District</td>
 	<td>Joypurhat District</td>
  	<td>Naogaon District</td>
  	<td>Natore District</td>
  	<td>Pabna District</td>
 	 </tr>

 	<tr>
  	<td>Rajshahi District</td>
 	<td>Sirajganj District</td>
  	<td>Gaibandha District</td>
  	<td>Dinajpur District</td>
  	<td>Kurigram District</td>
 	 </tr>

 	<tr>
  	<td>Lalmonirhat District</td>
 	<td>Nilphamari District</td>
  	<td>Rangpur District</td>
  	<td>Chuadanga District</td>
  	<td>Jessore District</td>
 	 </tr>

 	<tr>
  	<td>Khulna District</td>
 	<td>Kushtia District</td>
 	 </tr>

 	</table><br><br>
 
<?php

?>
 <div class="footer">
</div>

</body>
</html>